import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Needle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Needle extends Projectile
{
    /**
     * Act - do whatever the Needle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Needle(int yPos) {
        super("needle", 1, yPos, 15, 6);
        
        
    }
}
