# Plants-Vs-Zombies
The most complete Greenfoot remake of Plants Vs Zombies. Probably the most complete game ever made on Greenfoot.

**PLAY AT: https://www.greenfoot.org/scenarios/31337 or [>> Download gfar Here <<](https://github.com/TheExploration/Plants-Vs-Zombies/releases/tag/0.2)**

## Controls:
- Press "1" to skip to level 1.

- Press "2" to skip to level 2.

- Press "3" to skip to level 3...

Click to interact with mouse!



## Description:
A remake of Plants Vs Zombies DS Edition because its the only version I can find with the complete animation spritesheets.

Project size is ~14mb so far but its all cause of mp3 files.

Only made the first level so far.

Seed Packet recharged opacity is bugged in browser :(


A remake of Plants Vs Zombies DS Edition because its the only version I can find with the complete animation spritesheets. 
I might update to PC edition if I manage to find all the animation spritesheets

![demo2](https://github.com/TheExploration/Plants-Vs-Zombies/blob/master/demo2.png)
![demo](https://github.com/TheExploration/Plants-Vs-Zombies/blob/master/demo.png)


## Credit:
Art and Music by Popcap and Nintendo.
I mostly got art from spriters-resource.
Brickhead sprite made by Krakov95


## Changelog:
- Release
- Fix Audio
- Improve Wave System
- Added Repeater
- Added Brickhead
- Added 2nd Level
- Added Potato Mine
- Added Another level
