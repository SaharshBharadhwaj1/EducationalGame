import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * FallingSun class with math question for collecting
 * Includes boss fight harder math problems
 */
public class FallingSun extends FallingObject
{
    public MyWorld MyWorld;
    public GreenfootImage[] sun;
    public boolean clicked = false;
    public boolean beenClicked = false;
    public boolean collected = false;
    public long lastFrame2 = System.nanoTime();
    public long deltaTime2 = System.nanoTime();

    public FallingSun() {
        super(0.6, 0, 0, 0, (long)Random.Int(2000, 10000));
        sun = importSprites("sun", 2);
    }

    public void update() {
        currentFrame = System.nanoTime();
        deltaTime = (currentFrame - lastFrame) / 1000000;
        deltaTime2 = (currentFrame - lastFrame2) / 1000000;
        animate(sun, 200, true);

        if (!beenClicked) {
            if (checkClick()) {
                beenClicked = true;

                // Generate random math question
                String[] questionData = generateMathQuestion(MyWorld.isBossFight());
                String question = questionData[0];
                String correctAnswer = questionData[1];

                // Ask user the question
                String answer = Greenfoot.ask("Solve this to collect the sun: " + question);

                if (answer != null && answer.equals(correctAnswer)) {
                    // Correct input gives points
                    AudioPlayer.play(90, "points.mp3");
                    MyWorld.seedbank.suncounter.addSun(25);
                    collected = true;
                } else {
                    // Wrong input removes the sun 
                    getWorld().removeObject(this);
                    return;
                }
            }
        }

        if (!beenClicked) {
            // Regular falling behavior
            if (deltaTime < fallTime) {
                double x = getExactX() + hSpeed;
                double y = getExactY() + vSpeed;
                setLocation(x, y);

                turn(rotate);
                vSpeed = vSpeed + acceleration;
                lastFrame2 = System.nanoTime();
            } else {
                if (deltaTime2 > 10000) {
                    if (getImage().getTransparency() > 0) {
                        if (getImage().getTransparency() - 20 <= 0) {
                            getImage().setTransparency(0);
                        } else {
                            getImage().setTransparency(getImage().getTransparency() - 20);
                        }
                    } else {
                        getWorld().removeObject(this);
                        return;
                    }
                }
            }
        } else if (collected) {
            // Collected sun moves toward counter
            if (!(Math.abs(getX() - SunCounter.x) < 20 && Math.abs(getY() - SunCounter.y) < 20)) {
                turnTowards(SunCounter.x, SunCounter.y);
                move(20);
            }
        }
        checkDeath();
    }

    public boolean checkClick() {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null && Greenfoot.mouseClicked(null)) {
            MyWorld.moveHitbox();
            if (intersects(MyWorld.hitbox)) {
                clicked = true;    
            } else {
                clicked = false;
            }
            return clicked;
        }
        clicked = false;
        return clicked;
    }

    public void checkDeath() {
        if (Math.abs(getX() - SunCounter.x) < 20 && Math.abs(getY() - SunCounter.y) < 20) {
            move(0.5);
            if (getImage().getTransparency() > 0) {
                if (getImage().getTransparency() - 20 <= 0) {
                    getImage().setTransparency(0);
                } else {
                    getImage().setTransparency(getImage().getTransparency() - 20);
                }
            } else {
                getWorld().removeObject(this);
                return;
            }
        }
    }

    @Override
    public void addedToWorld(World world) {
        MyWorld = (MyWorld)getWorld();
    }

    /**
     * Generate a random math question.
     * If bossFight is true, problems are harder (larger numbers, more operations).
     * @return String array: [question, correctAnswer]
     */
    private String[] generateMathQuestion(boolean bossFight) {
        java.util.Random rand = new java.util.Random();
        int type;

        int a, b;
        String question;
        int answer;

        if (!bossFight) {
            // Normal Questions: Addition or Multiplication
            type = rand.nextInt(2); // 0 = addition, 1 = multiplication
            if (type == 0) { // Addition (10–50)
                a = rand.nextInt(41) + 10;
                b = rand.nextInt(41) + 10;
                question = a + " + " + b;
                answer = a + b;
            } else { // Multiplication (2–12)
                a = rand.nextInt(11) + 2;
                b = rand.nextInt(11) + 2;
                question = a + " x " + b;
                answer = a * b;
            }
        } else {
            // Boss Fight Questions: Divison and Multiplication aswell, harder questions
            type = rand.nextInt(4); // 0=addition, 1=multiplication, 2=subtraction, 3=division
            switch (type) {
                case 0: // Addition (50–150)
                    a = rand.nextInt(101) + 50;
                    b = rand.nextInt(101) + 50;
                    question = a + " + " + b;
                    answer = a + b;
                    break;
                case 1: // Multiplication (10–20)
                    a = rand.nextInt(11) + 10;
                    b = rand.nextInt(11) + 10;
                    question = a + " x " + b;
                    answer = a * b;
                    break;
                case 2: // Subtraction (50–150)
                    a = rand.nextInt(101) + 50;
                    b = rand.nextInt(50); 
                    question = a + " - " + b;
                    answer = a - b;
                    break;
                case 3: // Division (10–144) by 2–12, ensure it is divisible
                    b = rand.nextInt(11) + 2;
                    answer = rand.nextInt(11) + 10; // result
                    a = answer * b; // dividend
                    question = a + " ÷ " + b;
                    break;
                default:
                    a = 10; b = 10; answer = 20; question = "10 + 10";
            }
        }

        return new String[] { question, String.valueOf(answer) };
    }
}
